// user identification
  _kmq.push(['identify', '$user']);

// user identification
  _kmq.push(['record', 'My Event']);

// user identification
  _kmq.push(['record', 'My Event', {'My Property':'Value'}]);
;
